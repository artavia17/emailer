<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Template\Email\Create;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web"     group. Now create something great!
|
*/

Route::get('/', function () {
    return view('public.home');
})->name('inicio');

Auth::routes();

Route::middleware('auth')->group(function () {
    Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
    Route::get('/new-api', [Create::class, 'index'])->name('create-api');
    Route::post('/new-api', [Create::class, 'api_smtp'])->name('send_data_smtp');
    Route::get('/api-email', [Create::class, 'my_api'])->name('view_data_email');
    Route::post('/api-email', [Create::class, 'add_email'])->name('send_email_data');
});

