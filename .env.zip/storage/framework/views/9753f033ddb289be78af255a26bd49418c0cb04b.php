<header>
    <h1><?php echo e($header); ?></h1>
</header>
<div>
    <?php echo e(strip_tags(html_entity_decode($content), '<br>, <h2>, <h3>, <ul>, <li>, <p>, <span>')); ?>

</div>
<footer>
    <?php echo e($footer); ?>

</footer><?php /**PATH C:\Users\XPC\Desktop\Angular\email_api\resources\views/mail/api.blade.php ENDPATH**/ ?>