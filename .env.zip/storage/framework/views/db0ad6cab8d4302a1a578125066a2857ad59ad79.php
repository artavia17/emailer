<?php echo e($slot); ?>

<?php /**PATH C:\Users\XPC\Desktop\Angular\email_api\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>